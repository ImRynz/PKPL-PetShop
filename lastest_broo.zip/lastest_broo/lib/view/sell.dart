import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lastest_broo/controllers/product_controller.dart';
import 'package:lastest_broo/models/product.dart';
import 'package:lastest_broo/view/adding.dart';
import 'package:lastest_broo/view/dashboard.dart';
import 'package:lastest_broo/view/detail.dart';
import 'package:lastest_broo/view/home.dart';

class SellPage extends StatefulWidget {
  @override
  _SellPageState createState() => _SellPageState();
}

class _SellPageState extends State<SellPage> {
  int currentIndex = 2;

  final ProductController productController = Get.put(ProductController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sell Page'),
      ),
      body: Center(
        child: Obx(
          () => productController.products.isEmpty
              ? CircularProgressIndicator()
              : ListView.builder(
                  itemCount: productController.products.length,
                  itemBuilder: (context, index) {
                    Product product = productController.products[index];
                    return ListTile(
                      title: Text(product.title),
                      subtitle: Text("\$${product.price.toStringAsFixed(2)}"),
                      leading: Image.network(
                        product.image,
                        width: 60,
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (c) => Detail(
                              id: product.id,
                              title: product.title,
                              price: product.price,
                              image: product.image,
                              description: product.description,
                              rating: product.rating,
                              category: product.category,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.brown,
        unselectedItemColor: Colors.grey,
        currentIndex: currentIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_offer_outlined),
            label: 'Cart',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_3_outlined),
            label: 'Profile',
          ),
        ],
        onTap: (int index) {
          if (index != currentIndex) {
            setState(() {
              currentIndex = index;
            });
            switch (index) {
              case 0:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomePage()),
                );
                break;

              case 1:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Adding()),
                );
                break;

              case 3:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Dashboard()),
                );
                break;
            }
          }
        },
      ),
    );
  }
}
