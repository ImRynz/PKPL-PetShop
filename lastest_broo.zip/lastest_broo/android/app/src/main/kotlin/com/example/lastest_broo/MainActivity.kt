package com.example.lastest_broo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
